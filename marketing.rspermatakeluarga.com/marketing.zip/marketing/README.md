# Website CRUD Data Mahasiswa dengan Login Menggunakan Database dan PHP

Aplikasi Website CRUD sederhana yang digunakan sebagai mendata Data-Data Mahasiswa/i FTI dengan dilengkapi fitur Register, Export File, Login dan Logout. Untuk perancangan aplikasi website ini memanfaatkan simple CSS, Database MySQL, dan PHP. Sedangkan untuk pemanggilan alamat website menggunakan server XAMPP.

link download XAMPP : https://www.apachefriends.org/download.html

# Akun Login
Terdapat beberapa akun untuk login pada website data mahasiswa ini, seperti berikut :

- Admin
  Memiliki hak akses dalam menambah, menghapus, meng-export file serta melihat data mahasiswa FTI.
  
- Mahasiswa/i FTI UNMER
  Memiliki hak akses dalam melihat data mahasiswa FTI sebagai bentuk cross-check kebenaran data.
